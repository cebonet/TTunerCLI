/* (Auto-generated binary data file). */

#ifndef BINARY_BINARIES_H
#define BINARY_BINARIES_H

namespace binaries
{
    extern const char*  amenbreakloop_wav;
    const int           amenbreakloop_wavSize = 1234164;

};

#endif
