// Add this to your project to use Juce
// MacOS or iOS projects should not include this file.

#include "AppConfig.h"
#include "juce_amalgamated3.cpp"
