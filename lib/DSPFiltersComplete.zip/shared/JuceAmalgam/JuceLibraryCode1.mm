// Add this to your MacOS or iOS project to use Juce

#include "AppConfig.h"
#include "juce_amalgamated1.cpp"
