#!/bin/sh -e
mkdir -p m4
autoreconf --force --install --verbose

